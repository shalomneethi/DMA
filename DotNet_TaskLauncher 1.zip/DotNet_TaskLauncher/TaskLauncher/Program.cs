﻿using System;
using System.Collections.Generic;
using RabbitMQ.Client;

class Program
{
    static void Main()
    {
        string consumerHostName = "a4d13d257b493465daf63c8e17fadbf6-718735712.ap-south-1.elb.amazonaws.com";
        string producerHostName = "a4d13d257b493465daf63c8e17fadbf6-718735712.ap-south-1.elb.amazonaws.com";
        string consumerQueueName = "job_queue";
        string producerQueueName = "agent_queue";

        // Generate a random number between 0 and 10000
        Random random = new Random();
        int randomNumber = random.Next(0, 10001);

        // Create a new responseQueue with the name "Job-randomNumber"
        string responseQueueName = $"job-{randomNumber}-queue";

        var consumer = new MessageConsumer();

        // Start consuming messages
        int consumedMessageCount = consumer.StartConsuming(consumerHostName, consumerQueueName);

        if(consumedMessageCount>0)
        {

            // Pass responseQueueName to the producer and get the set of agent names
            var producer = new MessageProducer();
            var sentAgentNames = producer.StartProducing(producerHostName, producerQueueName, responseQueueName);

            // Monitor responses for all sent agents
            MonitorResponses(responseQueueName, sentAgentNames);

            Console.WriteLine("Writing back to STA-RMS database.");
        }

        Console.WriteLine("Press [Enter] to exit.");
        Console.ReadLine();
    }

    static void MonitorResponses(string responseQueueName, HashSet<string> expectedAgentNames)
    {
        string consumerHostName = "a4d13d257b493465daf63c8e17fadbf6-718735712.ap-south-1.elb.amazonaws.com";

        var receivedResponses = new HashSet<string>(); // Track the received responses
        var consumer = new MessageConsumer();

        Console.WriteLine("Watchdog Started..... "); 
        // Start consuming responses until responses are received for all expected agents
        while (!AllAgentsReceived(expectedAgentNames, receivedResponses))
        {
            // Start consuming responses
            var response = consumer.StartConsumingResponse(consumerHostName, responseQueueName);

            // Check if the response is not null
            if (response != null)
            {
                // Deserialize the JSON response to extract agent name and status
                var responseObject = Newtonsoft.Json.JsonConvert.DeserializeObject<AgentResponse>(response);

                // Check if the status is "completed" and add the agent name to receivedResponses
                if (responseObject != null && responseObject.status.Equals("completed", StringComparison.OrdinalIgnoreCase))
                {
                    // Process the response (you can add your processing logic here)
                    Console.WriteLine("Received response:");
                    Console.WriteLine(response);                    
                    receivedResponses.Add(responseObject.agentName);
                }
            }
            // Add an else block to handle the case when the response is null
            else
            {
                // Optionally, you can log a message or take other actions
                Console.WriteLine("Received a null response. Ignoring.");
            }
        }
    DeleteResponseQueue(consumerHostName, responseQueueName);
    
    Console.WriteLine("Received COMPLETED status for all agents. Monitoring completed.");
    Console.WriteLine("Response Queue is deleted");
}


    static void DeleteResponseQueue(string hostName, string queueName)
    {
        var factory = new ConnectionFactory() { HostName = hostName };
        using (var connection = factory.CreateConnection())
        using (var channel = connection.CreateModel())
        {
            // Delete the response queue
            channel.QueueDelete(queueName);
            Console.WriteLine($"Response queue '{queueName}' deleted.");
        }
    }

    static bool AllAgentsReceived(HashSet<string> expectedAgentNames, HashSet<string> receivedResponses)
    {
        // Check if all expected agent names are in the received responses
        return expectedAgentNames.All(agent => receivedResponses.Contains(agent));
    }

    // Define a class to represent the structure of the JSON response
    public class AgentResponse
    {
        public string agentName { get; set; }
        public string status { get; set; }
    }
}