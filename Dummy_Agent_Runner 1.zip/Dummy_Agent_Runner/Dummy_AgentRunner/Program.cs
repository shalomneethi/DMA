﻿using System;
using System.Diagnostics;
using System.Text;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Newtonsoft.Json;

namespace ConsumeCpuTime
{
    class Program
    {
        static void Main(string[] args)
        {
            int durationInSeconds = GetDurationFromConfiguration(); // Get the duration in seconds from configuration

            Console.WriteLine("Checking for messages in the queue...");

            // Perform CPU time consumption
            Console.WriteLine($"Consuming CPU time for {durationInSeconds} seconds...");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            // Wait for the overall duration
            while (stopwatch.Elapsed.TotalSeconds < durationInSeconds)
            {
                // Perform some CPU-bound work here.
                // For a simple example, we can use a loop.

                for (int i = 0; i < 1000000; i++)
                {
                    // Do some computational work.
                    double result = Math.Sqrt(i);
                }
            }

            stopwatch.Stop();

            Console.WriteLine("Finished consuming CPU time.");

           // Check for messages in the queue
            var receivedMessage = ConsumeFromRabbitMQ();

            if (receivedMessage != null)
            {
                Console.WriteLine($"Received message: {receivedMessage}");

                // Deserialize the received JSON message
                var messageObject = Newtonsoft.Json.JsonConvert.DeserializeObject<ReceivedMessage>(receivedMessage);

                // Extract values from the deserialized object
                var messageReference = messageObject.messageReference;
                var agentName = messageObject.agentName;

                Console.WriteLine($"Messagereference: {messageReference}, Agentname: {agentName}");

                // Send a completion message to the response queue
                SendCompletionMessage(messageReference, agentName);

            }
            else
            {
                Console.WriteLine("No messages found in the queue.");
            }            

            Console.WriteLine("Press [Enter] to exit.");
            Console.ReadLine();
        }

        static string ConsumeFromRabbitMQ()
        {
            var factory = new ConnectionFactory()
            {
                HostName = "a4d13d257b493465daf63c8e17fadbf6-718735712.ap-south-1.elb.amazonaws.com",
                UserName = "guest",
                Password = "guest"
            };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                // Declare the queue
                channel.QueueDeclare(queue: "agent_queue", durable: false, exclusive: false, autoDelete: false, arguments: null);

                // Get a single message
                var result = channel.BasicGet(queue: "agent_queue", autoAck: false);

                if (result != null)
                {
                    var body = result.Body;
                    var message = Encoding.UTF8.GetString(body.ToArray());

                    // Acknowledge the message manually
                    channel.BasicAck(result.DeliveryTag, false);

                    return message;
                }

                return null;
            }
        }

        static void SendCompletionMessage(string messageReference, string agentName)
        {
            var factory = new ConnectionFactory()
            {
                HostName = "a4d13d257b493465daf63c8e17fadbf6-718735712.ap-south-1.elb.amazonaws.com",
                UserName = "guest",
                Password = "guest"
            };
            using (var connection = factory.CreateConnection())
            using (var channel = connection.CreateModel())
            {
                // Construct the completion message
                var completionMessage = new { agentName, status = "completed" };
                var jsonMessage = Newtonsoft.Json.JsonConvert.SerializeObject(completionMessage);

                // Convert the completion message to a byte array
                var processedMessageBytes = Encoding.UTF8.GetBytes(jsonMessage);

                // Publish the completion message to the response queue
                channel.BasicPublish(exchange: "", routingKey: messageReference, basicProperties: null, body: processedMessageBytes);

                Console.WriteLine($"Completion message sent to response queue {messageReference}: {jsonMessage}");
            }
        }

        static int GetDurationFromConfiguration()
        {
            // You can configure the duration in various ways, such as command-line arguments or a configuration file.
            // For simplicity, this example hardcodes the duration to 20 seconds.
            // In a real application, you might read the duration from a configuration file, a command-line argument, or another source.
            return 10;
        }

        // Define a class to represent the received message format
        public class ReceivedMessage
        {
            public string agentName { get; set; }
            public string filePath { get; set; }
            public string messageReference { get; set; }
        }
    }
}
