using System;
using System.Text;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

public class MessageConsumer
{
    public int StartConsuming(string hostName, string queueName)
    {
        int consumedMessageCount = 0;

        var factory = new ConnectionFactory()
        {
            HostName = hostName,
            // Add any other necessary configuration here
        };

        using (var connection = factory.CreateConnection())
        using (var channel = connection.CreateModel())
        {
            channel.QueueDeclare(queue: queueName, durable: false, exclusive: false, autoDelete: false, arguments: null);

            var consumer = new EventingBasicConsumer(channel);
            consumer.Received += (model, ea) =>
            {
                var body = ea.Body;
                var message = Encoding.UTF8.GetString(body.ToArray());

                // Process the received message (you can add your processing logic here)
                Console.WriteLine("Consumer received message:");
                Console.WriteLine(message);

                // Increment the consumed message count
                consumedMessageCount++;
            };

            channel.BasicConsume(queue: queueName, autoAck: true, consumer: consumer);

            Console.WriteLine("Consumer is running.");
        }

        // Return the count of consumed messages
        return consumedMessageCount;
    }

    public string StartConsumingResponse(string hostName, string responseQueueName)
    {
        var factory = new ConnectionFactory()
        {
            HostName = hostName,
            // Add any other necessary configuration here
        };

        using (var connection = factory.CreateConnection())
        using (var channel = connection.CreateModel())
        {
            channel.QueueDeclare(queue: responseQueueName, durable: false, exclusive: false, autoDelete: false, arguments: null);

            var consumer = new EventingBasicConsumer(channel);
            BasicGetResult result = channel.BasicGet(responseQueueName, autoAck: true);

            if (result != null)
            {
                var body = result.Body;
                return Encoding.UTF8.GetString(body.ToArray());
            }

            // Return an empty string if no response is received
            return string.Empty;
        }
    }
}

