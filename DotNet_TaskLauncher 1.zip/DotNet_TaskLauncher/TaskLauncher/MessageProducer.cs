using System;
using System.Collections.Generic;
using System.Text;
using RabbitMQ.Client;

public class MessageProducer
{
    public HashSet<string> StartProducing(string hostName, string queueName, string responseQueueName)
    {
        var factory = new ConnectionFactory()
        {
            HostName = hostName,
            // Add any other necessary configuration here
        };

        using (var connection = factory.CreateConnection())
        using (var channel = connection.CreateModel())
        {
            channel.QueueDeclare(queue: queueName, durable: false, exclusive: false, autoDelete: false, arguments: null);

            // Generate and publish 7 random messages to the destination queue
            var random = new Random();
            var sentAgentNames = new HashSet<string>();

            for (int i = 0; i < 5; i++)
            {
                var randomAgentName = "agent" + random.Next(1, 10);
                sentAgentNames.Add(randomAgentName); // Add agent name to the set

                var randomFilePath = "/path/to/agent" + randomAgentName + "-file.txt";

                // Add MessageReference field using the passed responseQueueName
                var randomMessage = new
                {
                    agentName = randomAgentName,
                    filePath = randomFilePath,
                    messageReference = responseQueueName
                };

                string jsonMessage = Newtonsoft.Json.JsonConvert.SerializeObject(randomMessage);
                var processedMessageBytes = Encoding.UTF8.GetBytes(jsonMessage);
                channel.BasicPublish(exchange: "", routingKey: queueName, basicProperties: null, body: processedMessageBytes);
                Console.WriteLine("Producer published message: " + jsonMessage);
            }

            Console.WriteLine("Producer has completed.");
            return sentAgentNames;
        }
    }
}
