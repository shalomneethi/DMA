using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        string rabbitMQManagementApiBaseUrl = "a9fd2ad11dc064087a8740de68555152-1457086001.ap-south-1.elb.amazonaws.com/15672/api/";
        string username = "guest";
        string password = "guest";

        using (var httpClient = new HttpClient())
        {
            var byteArray = Encoding.ASCII.GetBytes($"{username}:{password}");
            httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

            // List all queues
            var queueList = await GetQueues(httpClient, rabbitMQManagementApiBaseUrl);
            Console.WriteLine("Queues before reset:");
            foreach (var queue in queueList)
            {
                Console.WriteLine(queue);
            }

            // Delete all queues
            await DeleteAllQueues(httpClient, rabbitMQManagementApiBaseUrl);

            Console.WriteLine("Queues after reset:");
            queueList = await GetQueues(httpClient, rabbitMQManagementApiBaseUrl);
            foreach (var queue in queueList)
            {
                Console.WriteLine(queue);
            }
        }

        Console.WriteLine("Press [Enter] to exit.");
        Console.ReadLine();
    }

    static async Task<List<string>> GetQueues(HttpClient httpClient, string baseUrl)
    {
        var response = await httpClient.GetStringAsync($"{baseUrl}queues");
        var queues = Newtonsoft.Json.JsonConvert.DeserializeObject<List<QueueInfo>>(response);
        return queues.Select(q => q.name).ToList();
    }

    static async Task DeleteAllQueues(HttpClient httpClient, string baseUrl)
    {
        var queues = await GetQueues(httpClient, baseUrl);

        foreach (var queue in queues)
        {
            await httpClient.DeleteAsync($"{baseUrl}queues/%2F/{queue}");
        }
    }

    public class QueueInfo
    {
        public string name { get; set; }
    }
}
